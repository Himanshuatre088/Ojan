from django.contrib import admin
from car_dealer_portal.models import Area, CarDealer, Vehicles
from customer_portal.models import Customer, Orders
# Register your models here.
admin.site.register(Area)
admin.site.register(CarDealer)
admin.site.register(Vehicles)
admin.site.register(Customer)
admin.site.register(Orders)